function foo() {
    return `foo
bar` + 1;
}