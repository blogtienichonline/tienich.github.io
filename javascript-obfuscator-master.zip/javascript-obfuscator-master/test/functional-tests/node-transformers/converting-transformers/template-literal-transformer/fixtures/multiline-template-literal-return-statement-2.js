function hi() {
    switch (true) {
        case true:
            return `foo
bar`;
    }
}