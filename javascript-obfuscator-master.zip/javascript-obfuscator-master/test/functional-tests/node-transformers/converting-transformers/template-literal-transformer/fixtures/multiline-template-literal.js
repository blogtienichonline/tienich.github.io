var test = `foo
bar`;
