function foo() {
    return `foo
bar`;
}