(function () {
    var variable = 1 + 2;
})();