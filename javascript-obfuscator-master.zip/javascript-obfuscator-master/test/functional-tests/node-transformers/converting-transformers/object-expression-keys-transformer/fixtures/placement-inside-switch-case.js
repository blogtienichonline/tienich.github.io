(function(){
    switch (true) {
        case true:
            var object = {
                foo: 'bar'
            };
    }
})();