(function () {
    const object = {foo: 'foo'},
        variable = object.foo;
})();