(function(){
    try {
        var object = {
            foo: 'bar'
        };
    } catch (e) {}
})();