(function(){
    this.state.foo = {
        foo: 'bar',
        baz: 'bark'
    };
    var foo = 1;
})();