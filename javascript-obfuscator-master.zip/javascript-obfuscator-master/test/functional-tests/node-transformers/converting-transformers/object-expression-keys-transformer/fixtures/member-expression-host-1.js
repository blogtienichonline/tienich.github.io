(function(){
    this.state = {
        foo: 'bar',
        baz: 'bark'
    };
})();