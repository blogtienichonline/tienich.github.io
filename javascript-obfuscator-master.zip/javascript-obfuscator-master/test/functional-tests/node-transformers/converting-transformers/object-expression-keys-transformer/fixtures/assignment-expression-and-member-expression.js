(function(){
    var n;
    (n = {foo: 'bar'}).baz = n.foo;
})();