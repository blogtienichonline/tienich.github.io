(function(){
    if (true) {
        var object = {
            foo: 'bar'
        };
    }
})();