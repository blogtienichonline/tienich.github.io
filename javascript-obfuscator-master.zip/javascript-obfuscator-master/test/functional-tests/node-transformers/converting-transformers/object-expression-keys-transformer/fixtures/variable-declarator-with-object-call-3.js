(function () {
    const object1 = {foo: 'foo'},
        object2 = {bar: 'bar'},
        variable = object2.bar;
})();