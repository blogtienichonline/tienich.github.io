(function(){
    var object;
    object = {
        foo: 'bar',
        baz: 'bark'
    };
})();