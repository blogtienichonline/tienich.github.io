(function(){
    var object = {
        foo: 'bar',
        baz: 'bark'
    };
})();