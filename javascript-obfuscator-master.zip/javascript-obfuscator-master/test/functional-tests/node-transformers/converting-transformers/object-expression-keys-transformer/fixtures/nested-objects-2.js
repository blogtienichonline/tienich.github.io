(function(){
    var object = {
        foo: 'bar',
        inner: {
            baz: 'bark',
            inner1: {
                hawk: 'geek'
            },
            cow: 'bear',

        },
        ball: 'door',
    };
})();