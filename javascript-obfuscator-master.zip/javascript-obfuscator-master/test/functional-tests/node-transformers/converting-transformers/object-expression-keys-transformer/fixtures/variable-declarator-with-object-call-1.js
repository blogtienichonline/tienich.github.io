(function () {
    const object = {foo: 'foo'};
    const variable = object.foo;
})();