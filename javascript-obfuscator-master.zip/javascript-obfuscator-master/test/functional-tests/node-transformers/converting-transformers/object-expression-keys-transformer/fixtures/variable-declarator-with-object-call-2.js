(function () {
    const test = 1,
        object = {foo: 'foo'};
    const variable = object.foo;
})();