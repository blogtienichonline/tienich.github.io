(function(){
    try {
    } catch (e) {
        var object = {
            foo: 'bar'
        };
    }
})();