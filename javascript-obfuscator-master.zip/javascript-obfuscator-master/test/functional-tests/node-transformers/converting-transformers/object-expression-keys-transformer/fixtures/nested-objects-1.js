(function(){
    var object = {
        foo: 'bar',
        inner: {
            inner1: {
                baz: 'bark'
            }
        }
    };
})();