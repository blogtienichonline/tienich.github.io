(function(){
    var object = {};
})();