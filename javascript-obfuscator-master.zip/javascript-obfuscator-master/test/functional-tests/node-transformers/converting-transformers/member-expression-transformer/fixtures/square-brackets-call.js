var test = console['log'];
