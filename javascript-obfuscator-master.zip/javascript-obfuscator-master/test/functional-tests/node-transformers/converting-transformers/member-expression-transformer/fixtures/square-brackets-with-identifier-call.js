var identifier = 'log';
var test = console[identifier];
