var test = console.log;
