(function () {
    class Foo {
        static async get() {}
    }
})();