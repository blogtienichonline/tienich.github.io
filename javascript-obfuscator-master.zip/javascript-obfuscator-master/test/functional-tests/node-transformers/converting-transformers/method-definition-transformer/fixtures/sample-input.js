class Foo {
    constructor () {}
    bar () {}
}
