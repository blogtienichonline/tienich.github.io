(function () {
    var key = 'foo';
    var test = {
        [key]: 1
    };
})();