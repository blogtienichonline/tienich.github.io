(function() {
    var obj1 = {foo: 1};
    var obj2 = {bar: 2};
    var newObj = {...obj1, ...obj2};
})();