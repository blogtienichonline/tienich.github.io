(function () {
    var test = {
        ['foo']: 1
    };
})();