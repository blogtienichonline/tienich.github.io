(function () {
    let a = 0;
    let b = 0;
    var test = {a, b};
})();