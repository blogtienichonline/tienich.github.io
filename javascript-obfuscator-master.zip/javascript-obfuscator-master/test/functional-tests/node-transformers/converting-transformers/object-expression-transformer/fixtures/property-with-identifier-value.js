var test = { foo: 0 };
