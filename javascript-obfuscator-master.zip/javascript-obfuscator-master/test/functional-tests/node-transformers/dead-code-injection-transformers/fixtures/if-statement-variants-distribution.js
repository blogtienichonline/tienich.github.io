(function(){
    if (true) {
        var foo = function () {
            console.log('abc');
        };
        var bar = function () {
            alert('def');
        };
        var baz = function () {
            alert('ghi');
        };
        var bark = function () {
            alert('jkl');
        };
        var hawk = function () {
            alert('mno');
        };

        foo();
        bar();
        baz();
        bark();
        hawk();
    }
})();