function test() {
    var importantVariableName = 'test';

    return importantVariableName.indexOf('test');
}