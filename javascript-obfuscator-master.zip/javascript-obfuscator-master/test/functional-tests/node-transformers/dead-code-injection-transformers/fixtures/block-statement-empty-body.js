(function(){
    function foo () {
        function inner1 () {}
        inner1();
    }
    function bar () {
        function inner2 () {}
        inner2();
    }
    function baz () {
        function inner3 () {}
        inner3();
    }
    function bark () {
        function inner4 () {}
        inner4();
    }
    function hawk () {
        function inner5 () {}
        inner5();
    }
})();