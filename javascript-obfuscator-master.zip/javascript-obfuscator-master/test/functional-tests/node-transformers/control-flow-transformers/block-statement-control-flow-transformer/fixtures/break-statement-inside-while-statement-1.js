(function () {
    while (true) {
        while (true) {
            break;
        }
        console.log(1);
        console.log(2);
        console.log(3);
        console.log(4);
        console.log(5);
    }
})();
