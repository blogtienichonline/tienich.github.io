(function () {
    var variable = true && false;
})();
