(function () {
    var expression1 = true;
    var expression2 = false;
    var variable = !expression1 && !expression2;
})();
