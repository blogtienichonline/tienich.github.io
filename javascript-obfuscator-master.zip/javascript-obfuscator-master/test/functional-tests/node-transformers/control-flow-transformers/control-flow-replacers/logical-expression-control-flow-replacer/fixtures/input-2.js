(function () {
    var variable1 = true && false;
    var variable2 = false && true;
})();
