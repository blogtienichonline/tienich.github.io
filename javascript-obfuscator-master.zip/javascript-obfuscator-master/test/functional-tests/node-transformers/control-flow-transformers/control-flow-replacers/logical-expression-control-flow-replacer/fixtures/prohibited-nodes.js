(function () {
    var object = {};
    var name = 'abc';
    var variable = object[name] && false;
})();
