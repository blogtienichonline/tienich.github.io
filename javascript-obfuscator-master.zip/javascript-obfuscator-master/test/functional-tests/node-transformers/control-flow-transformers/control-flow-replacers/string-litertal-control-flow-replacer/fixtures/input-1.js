(function () {
    var variable = 'test';
})();
