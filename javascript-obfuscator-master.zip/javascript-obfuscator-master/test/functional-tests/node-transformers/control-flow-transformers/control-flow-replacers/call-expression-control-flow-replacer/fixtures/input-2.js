(function () {
    function sum (a, b) {
        return a + b;
    }

    var variable1 = sum(1, 2);
    var variable2 = sum(2, 3);
})();
