(function () {
    var object = {
        sum: function (a, b) {
            return a + b;
        }
    };

    var variable = object.sum(1, 2);
})();
