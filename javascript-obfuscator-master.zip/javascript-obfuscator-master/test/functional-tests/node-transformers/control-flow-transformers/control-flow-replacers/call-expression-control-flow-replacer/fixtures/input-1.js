(function () {
    function sum (a, b) {
        return a + b;
    }

    var variable = sum(1, 2);
})();
