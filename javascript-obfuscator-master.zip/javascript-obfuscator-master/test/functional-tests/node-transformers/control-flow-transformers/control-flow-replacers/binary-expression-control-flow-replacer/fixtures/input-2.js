(function () {
    var variable1 = 1 + 2;
    var variable2 = 2 + 3;
})();
