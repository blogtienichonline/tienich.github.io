(function () {
    var foo = () => 1 + 2;
})();
