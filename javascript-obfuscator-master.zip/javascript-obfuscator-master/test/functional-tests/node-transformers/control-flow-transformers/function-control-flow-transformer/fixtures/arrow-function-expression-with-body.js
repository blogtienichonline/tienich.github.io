(function () {
    var foo = () => {
        var variable = 1 + 2;
    }
})();
