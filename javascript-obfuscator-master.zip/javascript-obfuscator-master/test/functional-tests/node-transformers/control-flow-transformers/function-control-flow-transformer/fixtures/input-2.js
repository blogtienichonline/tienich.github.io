(function () {
    function foo () {
        function bar () {
            var variable = 1 + 2;
        }
    }
})();
