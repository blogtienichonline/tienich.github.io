(function () {
    var test1 = 1 + 2;
    var test2 = 2 - 3;
})();
