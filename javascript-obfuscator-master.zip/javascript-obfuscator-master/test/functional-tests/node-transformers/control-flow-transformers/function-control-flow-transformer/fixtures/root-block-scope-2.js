(function () {
    function foo () {
        function bar () {
            function baz () {
                function bash () {
                    var variable = 1 + 2;
                }
            }
        }
    }
})();
