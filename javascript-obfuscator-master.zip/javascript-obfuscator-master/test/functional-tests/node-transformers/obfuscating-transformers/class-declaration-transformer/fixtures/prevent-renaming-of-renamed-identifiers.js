(function() {
    function test() {
        class inner {}
        let a, b, c, d;
    }
})();