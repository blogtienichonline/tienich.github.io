class Foo {}

export default Foo;