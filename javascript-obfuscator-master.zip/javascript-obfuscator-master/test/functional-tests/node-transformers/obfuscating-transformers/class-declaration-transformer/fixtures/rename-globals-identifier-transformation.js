class Foo {
    foo() {
        const foo = 1;
    }
}

class Bar {
    bar() {
        const bar = 2;
    }
}