function foo () {
    var test = 'abc';

    var object = {
        'test': 'cde'
    };

    console.log(test);
    console.log(object.test);
}