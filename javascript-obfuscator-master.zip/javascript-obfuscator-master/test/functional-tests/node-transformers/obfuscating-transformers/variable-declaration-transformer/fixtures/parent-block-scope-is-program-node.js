if (true) {
    var test = 10;
}

console.log(test);
