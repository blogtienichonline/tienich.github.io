(function () {
    var { bar } = { bar: 'foo' };

    console.log(bar);
})();
