(function () {
    if (true) {
        let test = 10;
    }

    console.log(test);
})();