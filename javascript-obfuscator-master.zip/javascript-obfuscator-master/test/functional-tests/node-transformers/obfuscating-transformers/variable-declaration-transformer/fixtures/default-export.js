var foo = 1;

export default foo;