(function() {
    var array = ['foo', 'bar', 'baz'];
    var [foo, ...rest] = array;
})();