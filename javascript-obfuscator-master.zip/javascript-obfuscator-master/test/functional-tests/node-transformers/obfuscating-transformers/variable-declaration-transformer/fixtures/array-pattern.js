function foo () {
    var [bar, baz] = [1, 2];

    console.log(bar, baz);
}