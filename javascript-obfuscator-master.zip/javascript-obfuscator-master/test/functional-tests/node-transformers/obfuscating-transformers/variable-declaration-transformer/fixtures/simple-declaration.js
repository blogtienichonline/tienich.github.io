function foo () {
    var test = 'abc';
    console.log(test);
}
