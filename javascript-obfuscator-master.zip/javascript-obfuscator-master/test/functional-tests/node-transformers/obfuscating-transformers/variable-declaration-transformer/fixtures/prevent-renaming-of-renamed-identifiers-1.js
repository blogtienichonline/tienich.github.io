(function() {
    function test() {
        var inner = 1;

        function a () {}
        function b () {}
        function c () {}
        function d () {}
    }
})();