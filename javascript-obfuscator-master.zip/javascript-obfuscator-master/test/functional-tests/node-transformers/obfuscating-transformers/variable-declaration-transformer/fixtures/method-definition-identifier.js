(function () {
    var bar = 1;

    class Foo {
        bar() {}
    }
})();