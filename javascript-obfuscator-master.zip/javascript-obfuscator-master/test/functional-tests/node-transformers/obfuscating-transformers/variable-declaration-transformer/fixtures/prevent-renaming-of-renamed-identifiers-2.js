(function() {
    function test() {
        var variable = 1;
        var g;

        function e () {
            var e = function () {

            }
        }
    }
})();