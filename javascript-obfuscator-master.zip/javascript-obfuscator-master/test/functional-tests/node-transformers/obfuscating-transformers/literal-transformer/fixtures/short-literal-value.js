var test = 'te';
