(function(){
    function foo () {
        console.log('a');
        var b;
        function b () {}
    }
})();