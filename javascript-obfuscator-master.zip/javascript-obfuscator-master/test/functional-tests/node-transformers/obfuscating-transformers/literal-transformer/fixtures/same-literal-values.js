var test = 'test';
var test = 'test';
object.test();