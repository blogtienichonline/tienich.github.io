const foo = 'foo';
const bar = 'bar';