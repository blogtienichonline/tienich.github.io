var foo = 'bar';
var baz = 'Cannot find module \'' + foo + '\'';