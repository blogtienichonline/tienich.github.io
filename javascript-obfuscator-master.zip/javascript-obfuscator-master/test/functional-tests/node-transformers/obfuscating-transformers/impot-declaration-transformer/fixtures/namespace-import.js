import * as foo from './foo';
console.log(foo);