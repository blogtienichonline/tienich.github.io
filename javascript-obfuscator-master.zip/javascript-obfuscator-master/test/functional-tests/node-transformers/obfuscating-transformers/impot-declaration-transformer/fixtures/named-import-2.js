import {foo as bar} from './foo';
console.log(bar);