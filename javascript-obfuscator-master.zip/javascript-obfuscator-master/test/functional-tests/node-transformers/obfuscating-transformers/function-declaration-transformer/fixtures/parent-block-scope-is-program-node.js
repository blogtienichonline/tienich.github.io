function foo () {
}

if (true) {
    foo();
}
