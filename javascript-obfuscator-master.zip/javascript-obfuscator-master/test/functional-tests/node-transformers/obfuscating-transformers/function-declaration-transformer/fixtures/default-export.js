function foo () {}

export default foo;