(function() {
    function test() {
        function inner() {}
        let a, b, c, d;
    }
})();