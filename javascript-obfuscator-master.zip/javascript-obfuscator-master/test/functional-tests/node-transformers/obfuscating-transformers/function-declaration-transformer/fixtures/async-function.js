(async function(){
    async function foo () {}

    await foo();
})();