function foo(bar) {
    [].find(({bar: baz}) => bar);
}