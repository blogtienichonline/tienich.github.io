function func ([foo, ...rest]) {
    return foo + rest;
}