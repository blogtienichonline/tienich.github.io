(function () {
    function foo (foo) {}

    return new foo();
})();