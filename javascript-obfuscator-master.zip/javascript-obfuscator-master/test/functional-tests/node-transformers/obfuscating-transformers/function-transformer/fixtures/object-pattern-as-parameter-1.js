(function () {
    var test = function ({ bar }) {
        return bar;
    }
})();
