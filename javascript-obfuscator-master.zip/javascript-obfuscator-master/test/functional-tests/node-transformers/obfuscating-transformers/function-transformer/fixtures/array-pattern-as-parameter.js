(function () {
    var test = function ([foo, bar]) {
        return foo + bar;
    }
})();
