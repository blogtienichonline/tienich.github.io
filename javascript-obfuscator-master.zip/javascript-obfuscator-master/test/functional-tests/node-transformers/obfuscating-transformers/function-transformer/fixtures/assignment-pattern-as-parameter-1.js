(function () {
    var test = function (bar = 1) {
        return bar;
    }
})();
