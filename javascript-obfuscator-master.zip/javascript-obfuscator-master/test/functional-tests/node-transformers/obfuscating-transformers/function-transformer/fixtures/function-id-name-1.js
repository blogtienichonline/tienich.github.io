(function(foo){
    function foo () {

    }

    return new foo();
})();