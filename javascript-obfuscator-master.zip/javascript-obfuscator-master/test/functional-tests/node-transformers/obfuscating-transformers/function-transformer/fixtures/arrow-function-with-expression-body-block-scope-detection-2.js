const foo = 1;
[]
    .map(foo => 1)
    .map(bar => [foo]);