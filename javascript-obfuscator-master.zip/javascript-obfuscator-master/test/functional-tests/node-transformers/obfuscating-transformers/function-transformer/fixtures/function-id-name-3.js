function foo (foo) {}

new foo();