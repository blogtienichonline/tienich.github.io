(function () {
    var test = function (test) {
        console.log(test);

        if (true) {
            var test = 5
        }

        variable = 6;

        return test;
    }
})();
