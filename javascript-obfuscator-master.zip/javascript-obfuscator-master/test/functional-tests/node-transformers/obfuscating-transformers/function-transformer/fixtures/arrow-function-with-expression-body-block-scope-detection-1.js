const foo = 1;
[]
    .map(foo => {
        return 1;
    })
    .map(bar => [foo]);