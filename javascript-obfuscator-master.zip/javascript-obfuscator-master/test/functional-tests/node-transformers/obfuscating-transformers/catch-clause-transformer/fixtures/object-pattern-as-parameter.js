(function () {
    try {

    } catch ({ name }) {
        return name;
    }
})();
