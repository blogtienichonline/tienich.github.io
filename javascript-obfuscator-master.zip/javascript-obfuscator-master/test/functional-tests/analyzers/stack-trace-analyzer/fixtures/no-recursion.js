var bar = function () {
};

bar();