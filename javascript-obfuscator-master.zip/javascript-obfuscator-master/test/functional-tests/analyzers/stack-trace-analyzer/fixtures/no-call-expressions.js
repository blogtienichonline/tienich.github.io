function bar () {

}

function baz () {

}
