var foo = function () {
    var test = 1;
};