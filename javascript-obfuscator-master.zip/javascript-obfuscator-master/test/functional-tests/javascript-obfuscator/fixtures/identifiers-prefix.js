var foo = 1;
var bar = 2;
var baz = function () {
    var bark = foo + bar;

    return bark;
};