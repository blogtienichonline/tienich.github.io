import {foo} from './foo';

var test = 1;