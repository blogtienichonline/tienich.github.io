module.exports = {
	compact: true,
	selfDefending: false,
	sourceMap: true
};