/**
 * @returns {string}
 */
export function StringArrayTemplate (): string {
    return `
        var {stringArrayName} = [{stringArray}];
    `;
}
