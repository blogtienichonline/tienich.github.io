import { IArrayStorage } from '../../interfaces/storages/IArrayStorage';

export type TStringArrayStorage = IArrayStorage <string>;
