import * as ESTree from 'estree';

export type TReplaceableIdentifiersNames = Map <string, ESTree.Identifier[]>;
