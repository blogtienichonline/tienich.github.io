export type TObjectMembersCallsChain = (string | number)[];
