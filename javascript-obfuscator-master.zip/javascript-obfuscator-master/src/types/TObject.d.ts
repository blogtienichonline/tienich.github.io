/* tslint:disable:interface-over-type-literal */

export type TObject <T = unknown> = {[key: string]: T};
