import { StringArrayEncoding } from '../../enums/StringArrayEncoding';

export type TStringArrayEncoding = boolean | StringArrayEncoding;
