import * as ESTree from 'estree';

export type TStatement = ESTree.Statement | ESTree.ModuleDeclaration;
