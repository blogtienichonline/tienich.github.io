import { IFileData } from '../../interfaces/cli/IFileData';

export type TSourceCodeData = string | IFileData[];
