import { TControlFlowStorage } from '../../storages/TControlFlowStorage';

export type TControlFlowStorageFactory = () => TControlFlowStorage;
