declare module 'escodegen-wallaby' {
    export * from 'escodegen';
}
