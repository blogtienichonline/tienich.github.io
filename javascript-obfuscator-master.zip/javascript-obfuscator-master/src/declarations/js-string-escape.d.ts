declare module 'js-string-escape' {
    function jsStringEscape (input: string): string;

    export = jsStringEscape;
}
