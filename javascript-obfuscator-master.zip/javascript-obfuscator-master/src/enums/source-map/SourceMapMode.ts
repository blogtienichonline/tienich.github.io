export enum SourceMapMode {
    Inline = 'inline',
    Separate = 'separate'
}
