export enum StringArrayEncoding {
    Base64 = 'base64',
    Rc4 = 'rc4'
}
