export enum ObfuscationEvent {
    AfterObfuscation = 'afterObfuscation',
    BeforeObfuscation = 'beforeObfuscation'
}
