export enum IdentifierObfuscatingReplacer {
    BaseIdentifierObfuscatingReplacer = 'BaseIdentifierObfuscatingReplacer'
}
