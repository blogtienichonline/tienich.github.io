export enum LiteralObfuscatingReplacer {
    BooleanLiteralObfuscatingReplacer = 'BooleanLiteralObfuscatingReplacer',
    NumberLiteralObfuscatingReplacer = 'NumberLiteralObfuscatingReplacer',
    StringLiteralObfuscatingReplacer = 'StringLiteralObfuscatingReplacer'
}
