export enum ControlFlowReplacer {
    BinaryExpressionControlFlowReplacer = 'BinaryExpressionControlFlowReplacer',
    CallExpressionControlFlowReplacer = 'CallExpressionControlFlowReplacer',
    LogicalExpressionControlFlowReplacer = 'LogicalExpressionControlFlowReplacer',
    StringLiteralControlFlowReplacer = 'StringLiteralControlFlowReplacer'
}
