export enum PropertiesExtractor {
    AssignmentExpressionPropertiesExtractor = 'AssignmentExpressionPropertiesExtractor',
    VariableDeclaratorPropertiesExtractor = 'VariableDeclaratorPropertiesExtractor'
}
