export enum ObfuscatingGuard {
    BlackListNodeGuard = 'BlackListNodeGuard',
    ConditionalCommentNodeGuard = 'ConditionalCommentNodeGuard'
}
