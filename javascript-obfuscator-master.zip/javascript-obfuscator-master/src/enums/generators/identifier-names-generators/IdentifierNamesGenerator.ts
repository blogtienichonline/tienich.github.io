export enum IdentifierNamesGenerator {
    HexadecimalIdentifierNamesGenerator = 'hexadecimal',
    MangledIdentifierNamesGenerator = 'mangled'
}
