export enum ObfuscationTarget {
    Browser = 'browser',
    BrowserNoEval = 'browser-no-eval',
    Node = 'node'
}
