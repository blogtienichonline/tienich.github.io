export enum CustomNodeGroup {
    ConsoleOutputCustomNodeGroup = 'ConsoleOutputCustomNodeGroup',
    DebugProtectionCustomNodeGroup = 'DebugProtectionCustomNodeGroup',
    DomainLockCustomNodeGroup = 'DomainLockCustomNodeGroup',
    SelfDefendingCustomNodeGroup = 'SelfDefendingCustomNodeGroup',
    StringArrayCustomNodeGroup = 'StringArrayCustomNodeGroup'
}
