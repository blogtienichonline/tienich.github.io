import { ContainerModule, interfaces } from 'inversify';

export const finalizingTransformersModule: interfaces.ContainerModule = new ContainerModule((bind: interfaces.Bind) => {
    // finalizing transformers

});
