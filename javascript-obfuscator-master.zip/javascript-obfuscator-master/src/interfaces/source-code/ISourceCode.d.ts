export interface ISourceCode {
    /**
     * @returns string
     */
    getSourceCode (): string;

    /**
     * @returns string
     */
    getSourceMap (): string;
}
