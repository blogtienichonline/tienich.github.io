export interface IEncodedValue {
    encodedValue: string;
    key: string | null;
}
