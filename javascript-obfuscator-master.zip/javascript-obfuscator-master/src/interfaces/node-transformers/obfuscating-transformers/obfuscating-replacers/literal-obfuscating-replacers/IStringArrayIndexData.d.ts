export interface IStringArrayIndexData {
    fromCache: boolean;
    index: string;
}
